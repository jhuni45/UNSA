#include <vector>
#include <iostream>
#include <algorithm>
#include <fstream>
#include <map>
#include <stdlib.h>
#include <time.h>
#include <cmath>

using namespace std;

#define ITER 200
#define N_HORMI 4
#define INITIAL_CITY 4
#define INITIAL_FERO 0.1

typedef int city;
typedef float num;
typedef vector<num> vec_num;

typedef struct{
      num distance = 0;
      vector<city> cities;
      string ruta="";
}ant;

ant mejor_global;
int mejor_local;
vector<ant> poblation;
string s_ciudades= "ABCDEFGHIJ";
int n_ciudades = s_ciudades.length();

num phi = 0.5, alfa = 1, beta = 1, Q=1, q0 = 0.5, qp = 0.5, q;

ofstream  file;
vec_num  visibility_Matrix, distances_Matrix, ferom_Matrix;

num content[] = { 0,12,3,23,1,5,23,56,12,11,
                  12,0,9,18,3,41,45,5,41,27,
                  3,9,0,89,56,21,12,48,14,29,
                  23,18,89,0,87,46,75,17,50,42,
                  1,3,56,87,0,55,22,86,14,33,
                  5,41,21,46,55,0,21,76,54,81,
                  23,45,12,75,22,21,0,11,57,48,
                  56,5,48,17,86,76,11,0,63,24,
                  12,41,14,50,14,54,57,63,0,9,
                  11,27,29,42,33,81,48,24,9,0};

void iniMatrizFeromona(){
      int aux;
      for (int i = 0; i < n_ciudades; i++){
            aux = i*n_ciudades+i;
            ferom_Matrix[aux] = 0;
      }
}

void obtenerMatrizVisibilidad(){
      for (size_t i = 0; i < n_ciudades; i++){
            for (size_t j = 0; j < n_ciudades; j++){
                  if(i != j)
                        visibility_Matrix[i*n_ciudades+j] = 1/distances_Matrix[i*n_ciudades+j];
            }
      }
}

void show_cities(vec_num  &vec, int n){
      int city;
      for (size_t i = 0; i < n; i++){
            for (size_t j = 0; j < n; j++)
                  file <<vec[i*n+j]<< " ";
            file<<endl;      
      }
}

void show_route(ant &tmp){
      for (size_t i = 0; i < tmp.cities.size(); i++){
            file<<tmp.cities[i]<<" ";
      }
      file<<endl;    
}

void show_Poblation(){
      file<<"------------------------------------------------\n";
      for (size_t i = 0; i < poblation.size(); i++){
            file<<"Hormiga "<<i<<": "<<poblation[i].ruta<<" - Costo: "<<poblation[i].distance<<" dis: ";
            show_route(poblation[i]);
      }
      file<<"------------------------------------------------\n";
}

void iniMatrices(){
      unsigned tam = sizeof(content) / sizeof(num);
      vec_num M(content,content+tam);
      vec_num b(n_ciudades*n_ciudades,INITIAL_FERO);
      vec_num c(n_ciudades*n_ciudades,0);
      distances_Matrix = M;     ferom_Matrix = b;     visibility_Matrix = c;
      iniMatrizFeromona();
      obtenerMatrizVisibilidad();
      file<<"---------Matriz de distacias-----------\n";
      show_cities(distances_Matrix,n_ciudades);
      file<<"---------Matriz de visibilidad-----------\n";
      show_cities(visibility_Matrix,n_ciudades);
}

// LISTO
void crearHormigas(){
      for (size_t i = 0; i < N_HORMI; i++){
            ant new_ant;
            new_ant.cities.push_back(INITIAL_CITY);
            new_ant.ruta += s_ciudades[INITIAL_CITY];
            poblation.push_back(new_ant);
      }     
}

// LISTO
int actual_ind(vector<city> &vec, int x){   
      auto it = find(vec.begin(), vec.end(), x);
      if(it != vec.end())
            return  distance(vec.begin(), it);
}

// LISTO
float get_index(ant &tmp, int pos, int j){
      if(pos > 0 && pos <n_ciudades){
            return (tmp.cities[pos+1]== j || tmp.cities[pos+1]== j) ? Q/tmp.distance : 0;
      }else if(pos == 0 ){
            return (tmp.cities[pos+1]== j)? Q/tmp.distance : 0;
      }else{
            return (tmp.cities[pos-1]== j) ? Q/tmp.distance : 0;
      }
}

float nivelFeromona(int i, int j){
      float t_ij = 0;
      city pos;
      vector<city> tmp;
      pos = actual_ind(mejor_global.cities,i);
      return get_index(mejor_global,pos,j);
}

void actualizarArco(int i, int j){
      file<<"Actualizamos el arco: "<<s_ciudades[i]<<" - "<<s_ciudades[j]<<" (v) (1-"<<qp<<") * "<<ferom_Matrix[i*n_ciudades+j]<<" + "<<qp<<" * "<<ferom_Matrix[i*n_ciudades+j]<<" = ";
      ferom_Matrix[i*n_ciudades+j] = ((1-qp)*ferom_Matrix[i*n_ciudades+j])+(qp*ferom_Matrix[i*n_ciudades+j]);
      file<<ferom_Matrix[i*n_ciudades+j]<<endl<<endl;
}

void actualizarMatrizFeronoma(){
      for (size_t i = 0; i < n_ciudades; i++){
            for (size_t j = 0; j < n_ciudades; j++){
                  if(j != i){
                        num aux=nivelFeromona(i,j);
                        file<<s_ciudades[i]<<"  -  "<<s_ciudades [j];
                        if (aux==0){
                              file<<" => "<<ferom_Matrix[i*n_ciudades+j]<< " + "<<aux;
                              ferom_Matrix[i*n_ciudades+j] = ferom_Matrix[i*n_ciudades+j]+aux;       
                        }
                        else{
                              file<<" => "<<ferom_Matrix[i*n_ciudades+j]*(1-phi)<<" + "<<aux*phi;
                              //ferom_Matrix[i*n_ciudades+j] = phi*ferom_Matrix[i*n_ciudades+j]+aux;
                              ferom_Matrix[i*n_ciudades+j] = (ferom_Matrix[i*n_ciudades+j]*(1-phi))+ (aux*phi);
                        }
                        file<<" => "<<ferom_Matrix[i*n_ciudades+j]<<endl;
                  }
            } 
      }
}


void recorridoIntensificacion_(ant &h1, int c_city,int &next_city){
      file<<"Recorrido por Intensificacion\n";
      num arg_max = 0;
      int pos_ct = c_city * n_ciudades;
      map<int,num> pb; //PROBABILIDADES
      city id_city;
      for (size_t i =0; i < n_ciudades; i++){
            auto it =find(h1.cities.begin(), h1.cities.end(), i);
            if(it == h1.cities.end()){
                  pb[i]=pow(ferom_Matrix[pos_ct+i],alfa)*pow(visibility_Matrix[pos_ct+i],beta);
                  file << s_ciudades[c_city]<<"-"<<s_ciudades[i]<<": t = "<<ferom_Matrix[pos_ct+i]<<" n = "<<visibility_Matrix[pos_ct+i]<<" t*n = "<<pb[i]<<endl;
                  if(arg_max < pb[i]){
                        arg_max = pb[i];
                        next_city = i;
                  }
            }
      }
}

void recorridoDiversificacion_(ant &h1, int c_city,int &next_city){
      file<<"Recorrido por Diversificacion\n";
      int pos_ct = c_city * n_ciudades;
      num sum=0;
      map<int,num> pb; //PROBABILIDADES
      city id_city;
      for (size_t i =0; i < n_ciudades; i++){
            auto it =find(h1.cities.begin(), h1.cities.end(), i);
            if(it == h1.cities.end()){
                  pb[i] = pow(ferom_Matrix[pos_ct+i],alfa)*pow(visibility_Matrix[pos_ct+i],beta);
                  file << s_ciudades[c_city]<<"-"<<s_ciudades[i]<<": t = "<<ferom_Matrix[pos_ct+i]<<" n = "<<visibility_Matrix[pos_ct+i]<<" t*n = "<<pb[i]<<endl;
                  sum+=pb[i];
            }
      }
      file<<"suma: "<<sum<<endl;
      num aleatorio = ((num)rand() * (1-0)) /(num)RAND_MAX + 0;
      num limite = 0;
      for(auto it = pb.begin();it != pb.end(); it++){
            it->second = it->second/sum;
            file<<s_ciudades[c_city]<<"-"<<s_ciudades[it->first]<<": Prob =  "<<it->second<<endl;
            if(limite < aleatorio && aleatorio<limite +it->second){
                  next_city = it->first;   
                  // break;
            }
            limite += it->second; 
      }
      file<<"Numero aleatorio para la probabilidad: "<<aleatorio<<endl;      
}

void elegirSgtCiudad(ant& h1){
      city c_city = h1.cities.back(); 
      city next_city;
      q = ((num)rand() * (1-0)) /(num)RAND_MAX + 0;
      file<<"valor de q: "<<q<<endl;
      if( q <= q0)
            recorridoIntensificacion_(h1,c_city,next_city);
      else
            recorridoDiversificacion_(h1,c_city,next_city);
      h1.cities.push_back(next_city);
      h1.distance += distances_Matrix[c_city*n_ciudades+ next_city];
      h1.ruta += s_ciudades[next_city];
      file<<"Ciudad siguiente: "<<s_ciudades[next_city]<<" ("<<distances_Matrix[c_city*n_ciudades+ next_city]<<")"<<endl;
      file<<"ruta: "<<h1.distance<<endl;
      actualizarArco(c_city,next_city);
}

void run(string filename){
      file.open(filename);
      file<<"Parametros:"<<endl
            <<"\tHormigas: "<<N_HORMI<<endl
            <<"\tphi: "<<phi<<endl
            <<"\talpha: "<<alfa<<endl
            <<"\tbeta: "<<beta<<endl
            <<"\tQ: "<<Q<<endl
            <<"\tq0: "<<q0<<endl
            <<"\tqp: "<<qp<<endl
            <<"\tIteraciones: "<<ITER<<endl<<endl;
      iniMatrices();
      for (int it = 0; it < ITER; it++){
            mejor_local=0;
            file<<"---------Matriz de feromona-----------\n";
            show_cities(ferom_Matrix,n_ciudades);
            file<<"================ ITERACION "<<it<<" ==================="<<endl;
            crearHormigas();
            for (int k = 0; k < N_HORMI; k++){
                  file<<"--------------Hormiga "<<k<<"--------------"<<endl;
                  while(poblation[k].cities.size()!=n_ciudades){
                        file<<"---------Elegir siguiente ciudad--------"<<endl;
                        elegirSgtCiudad(poblation[k]);
                  }
                  if(poblation[mejor_local].distance > poblation[k].distance)
                        mejor_local=k;
                  if(mejor_global.distance == 0)
                        mejor_global = poblation[mejor_local];
                  else
                        if(mejor_global.distance > poblation[mejor_local].distance) mejor_global = poblation[mejor_local];
                  file<<"camino: "<<poblation[k].ruta<<endl;
            }            
            show_Poblation();
            file<<"Mejor Hormiga local: "<<poblation[mejor_local].ruta<<" - Costo: "<<poblation[mejor_local].distance<<endl;
            file<<"Mejor global: "<< mejor_global.ruta <<" - Costo:"<<mejor_global.distance<<endl;
            actualizarMatrizFeronoma();
            show_Poblation();
            file<<"Mejor global: "<< mejor_global.ruta <<" - Costo:"<<mejor_global.distance<<endl;
            poblation.clear();
      }
      cout<<" Finalizado "<<endl;
}


int main(){
      srand(time(NULL));
      string fileName= "AntOut.txt";
      run(fileName);      
}